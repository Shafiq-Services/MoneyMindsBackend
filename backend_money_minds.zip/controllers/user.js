// userController.js
const User = require("../models/user");
const Avatar = require("../models/avatar");
const Otp = require("../models/otp-request");
const jwt = require("jsonwebtoken");
const sendEmail = require("../utils/sendEmail");
const { successResponse, errorResponse } = require("../utils/apiResponse");
const Video = require("../models/video");
const Campus = require("../models/campus");
const Course = require("../models/course");
const Book = require("../models/book");
const mongoose = require("mongoose");
const socketManager = require("../utils/socketManager");

// Helper function to format user data response consistently
const formatUserResponse = (user) => ({
  _id: user._id,
  firstName: user.firstName,
  lastName: user.lastName,
  username: user.username,
  email: user.email,
  phone: user.phone,
  avatar: user.avatar,
  bio: user.bio || '',
  country: user.country || '',
  createdAt: user.createdAt
});

const signUp = async (req, res) => {
  try {
    const { email, firstName, lastName, phone, bio, country } = req.body;
    const requiredFields = { email, firstName, lastName, phone };

    for (const [field, value] of Object.entries(requiredFields)) {
      if (!value) return errorResponse(res, 400, `${field} field is required`);
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return errorResponse(
        res,
        200,
        `An account with email ${email} already exists`
      );
    }

    const user = await User.create({ 
      email, 
      firstName, 
      lastName, 
      phone,
      bio: bio || '',
      country: country || ''
    });

    // Auto-send OTP after signup
    const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
    await Otp.create({
      email,
      code: otpCode,
      requestedAt: Date.now(),
      expiresAt: Date.now() + 5 * 60 * 1000,
    });
    await sendEmail(
      email,
      "Your One-Time Password (Money Minds)",
      `Hello ${firstName},\n\nYour One-Time Password (OTP) to continue with Money Minds is:\n\n🔐 OTP: ${otpCode}\n\nThis code is valid for 5 minutes. Please do not share it with anyone.\n\nIf you did not request this OTP, please ignore this message.\n\nThank you,  \nThe Money Minds Team`
    );

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "7d",
    });

    return successResponse(
      res,
      201,
      `Account created for ${email}. OTP has been sent to your email and will expire in 5 minutes.`,
      {
        token,
      }
    );
  } catch (err) {
    return errorResponse(
      res,
      500,
      "An error occurred while processing your request",
      err.message
    );
  }
};

const sendOtp = async (req, res) => {
  try {
    const { email } = req.query;
    if (!email)
      return errorResponse(res, 400, "Please provide an email address");

    const user = await User.findOne({ email });
    if (!user) {
      return errorResponse(
        res,
        404,
        "No account found with this email address"
      );
    }

    const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
    await Otp.create({
      email,
      code: otpCode,
      requestedAt: Date.now(),
      expiresAt: Date.now() + 5 * 60 * 1000,
    });
        await sendEmail(
            email,
            'Your One-Time Password (Money Minds)',
            `Hello ${user.firstName},

    Your One-Time Password (OTP) to continue with Money Minds is: ${otpCode}

    This code is valid for 5 minutes. Please do not share it with anyone.

    If you did not request this OTP, please ignore this message.

    Thank you,
    The Money Minds Team`
          );
    return successResponse(
      res,
      200,
      `OTP ${otpCode} has been sent to ${email}. It will expire in 5 minutes`
    );
  } catch (err) {
    return errorResponse(
      res,
      500,
      "Failed to generate and send OTP",
      err.message
    );
  }
};

const verifyOtp = async (req, res) => {
  try {
    const { email, otp } = req.body;
    if (!email || !otp)
      return errorResponse(
        res,
        400,
        "Both email and OTP are required for verification"
      );

    const validOtp = await Otp.findOne({ email, code: otp });
    if (!validOtp || validOtp.expiresAt < Date.now()) {
      return errorResponse(
        res,
        400,
        "The OTP provided is either invalid or has expired"
      );
    }
    await Otp.deleteMany({ email });
    const user = await User.findOne({ email });
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "7d",
    });
    return res.status(200).json({
      status: true,
      message: "OTP verification successful",
      token,
      user: formatUserResponse(user)
    });
  } catch (err) {
    return errorResponse(
      res,
      500,
      "An error occurred during OTP verification",
      err.message
    );
  }
};

const checkUsernameAvailability = async (req, res) => {
  try {
    const { username } = req.query;
    if (!username)
      return errorResponse(
        res,
        400,
        "Please provide a username to check availability"
      );

    const user = await User.findOne({ username });
    return successResponse(
      res,
      200,
      user
        ? `Username '${username}' is already taken`
        : `Username '${username}' is available`
    );
  } catch (err) {
    return errorResponse(
      res,
      500,
      "Failed to check username availability",
      err.message
    );
  }
};

const getAvatars = async (req, res) => {
  try {
    const avatars = await Avatar.find({});
    return res.status(200).json({
      status: true,
      message: "Avatar list retrieved successfully",
      avatars,
    });
  } catch (err) {
    return errorResponse(
      res,
      500,
      "Failed to retrieve avatar list",
      err.message
    );
  }
};

const setUsernameAndAvatar = async (req, res) => {
  try {
    const { username, avatarUrl } = req.body;
    if (!username || !avatarUrl)
      return errorResponse(
        res,
        400,
        "Both username and avatar URL are required"
      );

    const user = await User.findById(req.userId);
    if (!user) return errorResponse(res, 404, "User account not found");

    user.username = username;
    user.avatar = avatarUrl;
    await user.save();
    return successResponse(
      res,
      200,
      "Username and avatar have been successfully updated"
    );
  } catch (err) {
    return errorResponse(
      res,
      500,
      "Failed to update username and avatar",
      err.message
    );
  }
};

const modifyAvatar = async (req, res) => {
  try {
    const { avatarUrl } = req.body;
    if (!avatarUrl)
      return errorResponse(res, 400, "Please provide an avatar URL");

    const user = await User.findById(req.userId);
    user.avatar = avatarUrl;
    await user.save();
    return successResponse(res, 200, "Avatar has been successfully updated", {
      user: formatUserResponse(user)
    });
  } catch (err) {
    return errorResponse(res, 500, "Failed to update avatar", err.message);
  }
};

const modifyUsername = async (req, res) => {
  try {
    const { username } = req.body;
    if (!username) return errorResponse(res, 400, "Please provide a username");

    const exists = await User.findOne({ username });
    if (exists)
      return errorResponse(
        res,
        400,
        "This username is already taken. Please choose another one"
      );

    const user = await User.findById(req.userId);
    user.username = username;
    await user.save();
    return successResponse(res, 200, "Username has been successfully updated");
  } catch (err) {
    return errorResponse(res, 500, "Failed to update username", err.message);
  }
};

// Add new endpoints for bio and country
const modifyBio = async (req, res) => {
  try {
    const { bio } = req.body;
    if (bio === undefined) return errorResponse(res, 400, "Please provide a bio");

    const user = await User.findById(req.userId);
    if (!user) return errorResponse(res, 404, "User account not found");

    user.bio = bio;
    await user.save();
    return successResponse(res, 200, "Bio has been successfully updated", {
      user: formatUserResponse(user)
    });
  } catch (err) {
    return errorResponse(res, 500, "Failed to update bio", err.message);
  }
};

const modifyCountry = async (req, res) => {
  try {
    const { country } = req.body;
    if (!country) return errorResponse(res, 400, "Please provide a country");

    const user = await User.findById(req.userId);
    if (!user) return errorResponse(res, 404, "User account not found");

    user.country = country;
    await user.save();
    return successResponse(res, 200, "Country has been successfully updated", {
      user: formatUserResponse(user)
    });
  } catch (err) {
    return errorResponse(res, 500, "Failed to update country", err.message);
  }
};

const getUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    if (!user) return errorResponse(res, 404, "User account not found");

    // Get recent video/film watching data
    let recentVideo = null;
    if (socketManager.videoProgress[req.userId]) {
      const videoProgressEntries = Object.entries(socketManager.videoProgress[req.userId]);
      if (videoProgressEntries.length > 0) {
        // Sort by last updated time (most recent first)
        const sortedProgress = videoProgressEntries.sort((a, b) => 
          (b[1].lastUpdated || 0) - (a[1].lastUpdated || 0)
        );
        
        const [mostRecentVideoId, progress] = sortedProgress[0];
        const video = await Video.findById(mostRecentVideoId);
        if (video) {
          recentVideo = {
            _id: video._id,
            title: video.title,
            description: video.description,
            type: video.type,
            videoUrl: video.videoUrl,
            posterUrl: video.posterUrl,
            resolutions: video.resolutions || [],
            createdAt: video.createdAt,
            watchProgress: progress.percentage,
            watchSeconds: progress.seconds,
            totalDuration: progress.totalDuration,
            contentType: video.type === 'film' ? 'film' : 'episode'
          };
        }
      }
    }

    // Get recent course learning data
    let recentCourse = null;
    const userCampuses = await Campus.find({ 'members.userId': req.userId });
    if (userCampuses.length > 0) {
      const campusIds = userCampuses.map(campus => campus._id);
      
      // Get courses with progress
      const coursesWithProgress = await Course.aggregate([
        { $match: { campusId: { $in: campusIds } } },
        {
          $lookup: {
            from: 'lessons',
            localField: '_id',
            foreignField: 'courseId',
            as: 'lessons'
          }
        },
        {
          $addFields: {
            totalVideos: {
              $size: {
                $filter: {
                  input: '$lessons',
                  as: 'lesson',
                  cond: {
                    $and: [
                      { $ne: ['$$lesson.videoUrl', null] },
                      { $ne: ['$$lesson.videoUrl', ''] }
                    ]
                  }
                }
              }
            },
            videosWithProgress: {
              $size: {
                $filter: {
                  input: '$lessons',
                  as: 'lesson',
                  cond: {
                    $and: [
                      { $ne: ['$$lesson.videoUrl', null] },
                      { $ne: ['$$lesson.videoUrl', ''] }
                    ]
                  }
                }
              }
            }
          }
        }
      ]);

      // Process courses to find the most recent one with progress
      let mostRecentCourse = null;
      let latestProgressTime = 0;

      for (const course of coursesWithProgress) {
        let courseProgress = 0;
        let courseLatestTime = 0;

        course.lessons.forEach(lesson => {
          if (lesson.videoUrl && lesson.videoUrl.trim() !== '') {
            const progress = socketManager.videoProgress[req.userId] && 
                            socketManager.videoProgress[req.userId][lesson._id.toString()];
            if (progress && progress.percentage > 0) {
              courseProgress++;
              courseLatestTime = Math.max(courseLatestTime, progress.lastUpdated || 0);
            }
          }
        });

        if (courseProgress > 0 && courseLatestTime > latestProgressTime) {
          latestProgressTime = courseLatestTime;
          const campus = userCampuses.find(c => c._id.toString() === course.campusId.toString());
          
          mostRecentCourse = {
            _id: course._id,
            campusId: course.campusId,
            campusTitle: campus ? campus.title : '',
            campusSlug: campus ? campus.slug : '',
            campusImageUrl: campus ? campus.imageUrl : '',
            title: course.title,
            imageUrl: course.imageUrl,
            totalVideos: course.totalVideos,
            videosWithProgress: courseProgress,
            courseProgress: course.totalVideos > 0 ? Math.round((courseProgress / course.totalVideos) * 100) : 0,
            createdAt: course.createdAt
          };
        }
      }

      recentCourse = mostRecentCourse;
    }

    // Get recent book reading data
    let recentBook = null;
    const continueReadingBooks = await Book.find(
      { 
        isOpened: { 
          $exists: true, 
          $ne: [], 
          $in: [new mongoose.Types.ObjectId(req.userId)]
        }
      },
      { isOpened: 0 }
    ).sort({ updatedAt: -1 }).limit(1).lean();

    if (continueReadingBooks.length > 0) {
      const book = continueReadingBooks[0];
      recentBook = {
        _id: book._id,
        title: book.title,
        author: book.author,
        image: book.image,
        content: book.content,
        createdAt: book.createdAt
      };
    }

    return successResponse(res, 200, "User profile retrieved successfully", {
      user: formatUserResponse(user),
      recentVideo,
      recentCourse,
      recentBook
    });
  } catch (err) {
    return errorResponse(res, 500, "Failed to retrieve user profile", err.message);
  }
};

module.exports = {
  signUp,
  sendOtp,
  verifyOtp,
  checkUsernameAvailability,
  getAvatars,
  setUsernameAndAvatar,
  modifyAvatar,
  modifyUsername,
  modifyBio,
  modifyCountry,
  getUserProfile,
};
