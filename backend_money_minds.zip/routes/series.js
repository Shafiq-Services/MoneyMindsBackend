const express = require('express');
const router = express.Router();
const { addSeries, getRandomSeries } = require('../controllers/series');
const authMiddleware = require('../middlewares/auth');

// POST /api/series
router.use(authMiddleware);
router.post('/add-series', addSeries);
router.get('/', getRandomSeries);

module.exports = router; 